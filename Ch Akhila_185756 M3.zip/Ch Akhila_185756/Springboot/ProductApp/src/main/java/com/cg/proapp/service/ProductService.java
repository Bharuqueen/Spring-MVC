package com.cg.proapp.service;

import java.util.List;

import com.cg.proapp.bean.Product;

public interface ProductService {
	List<Product> getAllProducts();
	   Product getProductById(int id);
	void updateProduct(Product pro);
	    void addProduct(Product pro);
	    void deleteProduct(int id);
		boolean validateCategoryAndQuantity(String myCategory, int myQuantity);
		List<Product> getProductByPrice(int minPrice, int maxPrice);
	    
}
