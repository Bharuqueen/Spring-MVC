package com.cg.cust.exception;

public class CustomerException extends Exception
{
public CustomerException()
{
	
}
public CustomerException(String msg)
{
	super(msg);
}
}
