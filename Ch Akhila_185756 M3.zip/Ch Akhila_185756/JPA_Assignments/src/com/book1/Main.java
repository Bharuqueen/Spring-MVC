package com.book1;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Main {
	public static void main(String[] args) {
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager entityManager=factory.createEntityManager();
	Author author=new Author();
	author.setName("Chetan Bhagat");
	Book book1=new Book();
	book1.setTitle("Two States");
	book1.setPrice(150);
	book1.setAuthor(author);
	author.getBook().add(book1);
	Book book2=new Book();
	book2.setTitle("Half girlfriend");
	book2.setPrice(1001);
	book2.setAuthor(author);
	author.getBook().add(book2);
	
	entityManager.getTransaction().begin();
	
	entityManager.persist(author);
	TypedQuery<Book> query1=entityManager.createQuery("FROM Book",Book.class);
	List<Book> books1=query1.getResultList();
	for(Book book:books1) {
		System.out.println(book);
	}
	System.out.println();
	TypedQuery<Author> query2=entityManager.createQuery("from Author where name='J K Rowling'", Author.class);
	Author authorId=query2.getSingleResult();
	int getId=authorId.getID();
	TypedQuery<Book> query3=entityManager.createQuery("from Book where ID=:id", Book.class);
	query3.setParameter("id", getId);
	List<Book> books2=query3.getResultList();
	for(Book book:books2) {
	System.out.println(book);
    }
	System.out.println();
	TypedQuery<Book> query4=entityManager.createQuery("from Book where price between 1000 and 1234", Book.class);
	List<Book> books3=query4.getResultList();
	for(Book book:books3) {
	System.out.println(book);
    }
	System.out.println();
	
	TypedQuery<Book> query5=entityManager.createQuery("from Book where ISBN=:gisbn", Book.class);
	query5.setParameter("gisbn", book1.getISBN());
	Book bookIsbn=query5.getSingleResult();
	int bookId=bookIsbn.getAuthor().getID();
	System.out.println(bookId);
	TypedQuery<Author> query6=entityManager.createQuery("from Author where ID=:id", Author.class);
	query6.setParameter("id", bookId);
	Author authors=query6.getSingleResult();
	System.out.println(authors.getName());
	System.out.println();
	
	entityManager.getTransaction().commit();

}
}

