package com.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
public class Main {
	public static void main(String args[]) {
UserDetails user=new UserDetails();
user.setName("sonu");
VehicleDetails vd=new VehicleDetails();
vd.setVehicleName("car");
VehicleDetails vd1=new VehicleDetails();
vd1.setVehicleName("bike");
vd.setUser1(user);
vd1.setUser1(user);
user.getVehicle().add(vd);
user.getVehicle().add(vd1);

EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
EntityManager em=factory.createEntityManager();

em.getTransaction().begin();
em.persist(user);
em.getTransaction().commit();
System.out.println("Data Saved");
}
}
